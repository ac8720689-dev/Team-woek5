/**
 * Team Profit & Performance Dashboard — Frontend Logic
 */

const API = "/api";
let adminToken = localStorage.getItem("adminToken") || null;
let chartInstance = null;
let pendingDeleteId = null;
let currentPeriod = "all";

// ── Helpers ──
function formatINR(num) {
  const n = Number(num) || 0;
  const abs = Math.abs(n);
  return "₹" + abs.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

function showToast(msg, type = "success") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className = `toast ${type}`;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 3000);
}

function show(el) {
  el.classList.remove("hidden");
}
function hide(el) {
  el.classList.add("hidden");
}

// ── API ──
async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (adminToken) headers["Authorization"] = `Bearer ${adminToken}`;
  const res = await fetch(`${API}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || data.error || "Request failed");
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

// ── Dashboard Render ──
function renderStats(stats) {
  const net = stats.net_result;
  const isProfit = stats.is_profit;

  document.getElementById("netAmount").textContent = formatINR(net);
  document.getElementById("netLabel").textContent = isProfit ? "Net Profit" : "Net Loss";

  const hero = document.getElementById("heroCard");
  hero.classList.toggle("is-profit", isProfit);
  hero.classList.toggle("is-loss", !isProfit);

  document.getElementById("totalProfit").textContent = formatINR(stats.total_profit);
  document.getElementById("totalLoss").textContent = formatINR(stats.total_loss);
  document.getElementById("totalWins").textContent = stats.total_wins;
  document.getElementById("totalLosses").textContent = stats.total_losses;

  // Win rate ring
  const rate = stats.win_rate;
  document.getElementById("winRateValue").textContent = rate + "%";
  document.getElementById("detailWins").textContent = stats.total_wins;
  document.getElementById("detailLosses").textContent = stats.total_losses;

  const circumference = 2 * Math.PI * 70; // r=70
  const offset = circumference - (rate / 100) * circumference;
  const ring = document.getElementById("winRateRing");
  ring.style.strokeDasharray = circumference;
  ring.style.strokeDashoffset = offset;
  ring.style.stroke = rate >= 50 ? "#22c55e" : "#ef4444";
}

function renderChart(chartData) {
  const ctx = document.getElementById("performanceChart").getContext("2d");
  if (chartInstance) chartInstance.destroy();

  const labels = chartData.labels.length ? chartData.labels : ["No data"];
  const profit = chartData.profit.length ? chartData.profit : [0];
  const loss = chartData.loss.length ? chartData.loss : [0];

  chartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Profit",
          data: profit,
          backgroundColor: "rgba(34, 197, 94, 0.7)",
          borderRadius: 4,
          maxBarThickness: 28
        },
        {
          label: "Loss",
          data: loss,
          backgroundColor: "rgba(239, 68, 68, 0.7)",
          borderRadius: 4,
          maxBarThickness: 28
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          labels: { color: "#9aa0b0", font: { family: "Inter", size: 12 } }
        },
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ₹${Number(ctx.raw).toLocaleString("en-IN")}`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: "#6b7280", maxRotation: 45, font: { size: 11 } },
          grid: { color: "rgba(42, 47, 61, 0.5)" }
        },
        y: {
          ticks: {
            color: "#6b7280",
            callback: (v) => "₹" + (v >= 1000 ? (v / 1000) + "k" : v)
          },
          grid: { color: "rgba(42, 47, 61, 0.5)" }
        }
      }
    }
  });
}

async function loadDashboard(period = "all") {
  currentPeriod = period;
  try {
    const data = await api(`/stats?period=${period}`);
    hide(document.getElementById("loadingState"));
    hide(document.getElementById("emptyState"));

    if (data.stats.total_entries === 0) {
      show(document.getElementById("emptyState"));
      hide(document.getElementById("dashboard"));
    } else {
      show(document.getElementById("dashboard"));
      renderStats(data.stats);
      renderChart(data.chart);
    }
  } catch (err) {
    hide(document.getElementById("loadingState"));
    showToast(err.message || "Failed to load data", "error");
  }
}

// ── Period Tabs ──
document.querySelectorAll(".period-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".period-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    loadDashboard(btn.dataset.period);
  });
});

// ── Admin Login ──
const loginModal = document.getElementById("loginModal");
const adminPanel = document.getElementById("adminPanel");
const adminBtn = document.getElementById("adminBtn");

adminBtn.addEventListener("click", () => {
  if (adminToken) {
    openAdminPanel();
  } else {
    show(loginModal);
    document.getElementById("adminCodeInput").value = "";
    hide(document.getElementById("loginError"));
    document.getElementById("adminCodeInput").focus();
  }
});

document.getElementById("cancelLogin").addEventListener("click", () => hide(loginModal));
document.querySelector("#loginModal .modal-backdrop").addEventListener("click", () => hide(loginModal));

document.getElementById("submitLogin").addEventListener("click", doLogin);
document.getElementById("adminCodeInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") doLogin();
});

async function doLogin() {
  const code = document.getElementById("adminCodeInput").value.trim();
  if (!code) return;
  try {
    const data = await api("/admin/login", {
      method: "POST",
      body: JSON.stringify({ code })
    });
    adminToken = data.token;
    localStorage.setItem("adminToken", adminToken);
    hide(loginModal);
    showToast("Admin access granted");
    openAdminPanel();
  } catch (err) {
    const errEl = document.getElementById("loginError");
    errEl.textContent = err.data?.message || "Access Denied";
    show(errEl);
  }
}

async function openAdminPanel() {
  show(adminPanel);
  resetForm();
  await loadEntries();
}

document.getElementById("logoutBtn").addEventListener("click", async () => {
  try {
    await api("/admin/logout", { method: "POST" });
  } catch (_) {}
  adminToken = null;
  localStorage.removeItem("adminToken");
  hide(adminPanel);
  showToast("Logged out");
});

document.querySelector("#adminPanel .modal-backdrop").addEventListener("click", () => hide(adminPanel));

// ── Form ──
function resetForm() {
  document.getElementById("formTitle").textContent = "Add Entry";
  document.getElementById("editId").value = "";
  document.getElementById("entryDate").value = new Date().toISOString().slice(0, 10);
  document.getElementById("entryType").value = "profit";
  document.getElementById("entryAmount").value = "";
  document.getElementById("entryResult").value = "win";
  document.getElementById("entryNote").value = "";
  document.getElementById("saveBtn").textContent = "Save";
}

document.getElementById("cancelForm").addEventListener("click", resetForm);

document.getElementById("entryForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("editId").value;
  const payload = {
    date: document.getElementById("entryDate").value,
    type: document.getElementById("entryType").value,
    amount: parseFloat(document.getElementById("entryAmount").value),
    result: document.getElementById("entryResult").value,
    note: document.getElementById("entryNote").value
  };

  try {
    if (id) {
      await api(`/admin/entries/${id}`, { method: "PUT", body: JSON.stringify(payload) });
      showToast("Changes saved successfully.");
    } else {
      await api("/admin/entries", { method: "POST", body: JSON.stringify(payload) });
      showToast("Entry added successfully");
    }
    resetForm();
    await loadEntries();
    await loadDashboard(currentPeriod);
  } catch (err) {
    if (err.status === 401) {
      adminToken = null;
      localStorage.removeItem("adminToken");
      hide(adminPanel);
      show(loginModal);
      showToast("Session expired. Please login again.", "error");
    } else {
      showToast(err.message || "Failed to save", "error");
    }
  }
});

// ── Entries List ──
async function loadEntries() {
  try {
    const data = await api("/entries");
    const list = document.getElementById("entriesList");
    if (!data.entries.length) {
      list.innerHTML = `<p style="color:var(--text-dim);font-size:0.9rem;padding:12px 0;">No entries yet.</p>`;
      return;
    }
    list.innerHTML = data.entries
      .map(
        (e) => `
      <div class="entry-item" data-id="${e.id}">
        <span class="entry-badge ${e.type}">${e.type}</span>
        <div class="entry-info">
          <div class="entry-amount">${formatINR(e.amount)} · ${e.result}</div>
          <div class="entry-meta">${e.date}${e.note ? " · " + e.note : ""}</div>
        </div>
        <div class="entry-actions">
          <button class="edit-btn" data-id="${e.id}">Edit</button>
          <button class="del-btn" data-id="${e.id}">Delete</button>
        </div>
      </div>`
      )
      .join("");

    list.querySelectorAll(".edit-btn").forEach((btn) => {
      btn.addEventListener("click", () => startEdit(Number(btn.dataset.id), data.entries));
    });
    list.querySelectorAll(".del-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        pendingDeleteId = Number(btn.dataset.id);
        show(document.getElementById("confirmModal"));
      });
    });
  } catch (err) {
    if (err.status === 401) {
      adminToken = null;
      localStorage.removeItem("adminToken");
    }
  }
}

function startEdit(id, entries) {
  const e = entries.find((x) => x.id === id);
  if (!e) return;
  document.getElementById("formTitle").textContent = "Edit Entry";
  document.getElementById("editId").value = e.id;
  document.getElementById("entryDate").value = e.date;
  document.getElementById("entryType").value = e.type;
  document.getElementById("entryAmount").value = e.amount;
  document.getElementById("entryResult").value = e.result;
  document.getElementById("entryNote").value = e.note || "";
  document.getElementById("saveBtn").textContent = "Update";
}

// ── Delete Confirm ──
document.getElementById("cancelDelete").addEventListener("click", () => {
  hide(document.getElementById("confirmModal"));
  pendingDeleteId = null;
});
document.querySelector("#confirmModal .modal-backdrop").addEventListener("click", () => {
  hide(document.getElementById("confirmModal"));
  pendingDeleteId = null;
});

document.getElementById("confirmDelete").addEventListener("click", async () => {
  if (!pendingDeleteId) return;
  try {
    await api(`/admin/entries/${pendingDeleteId}`, { method: "DELETE" });
    showToast("Entry deleted successfully");
    hide(document.getElementById("confirmModal"));
    pendingDeleteId = null;
    await loadEntries();
    await loadDashboard(currentPeriod);
  } catch (err) {
    showToast(err.message || "Delete failed", "error");
  }
});

// ── Init ──
document.addEventListener("DOMContentLoaded", () => {
  loadDashboard("all");
});
