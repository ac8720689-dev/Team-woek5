# Team Profit & Performance Dashboard

Professional team analytics dashboard with secure admin management.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Flask](https://img.shields.io/badge/Flask-3.x-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features

- **Main Dashboard** — Net Profit/Loss hero card, Total Profit, Total Loss, Total Wins, Total Losses
- **Win Rate** — Circular progress ring with automatic calculation
- **Performance Chart** — Profit vs Loss bar chart (All Time / Monthly / Weekly / Daily)
- **Admin System** — Secret code protected (`dmts9695`) — hashed on backend, never exposed in frontend
- **CRUD Entries** — Add / Edit / Delete with confirmation dialog
- **Auto Calculations** — All totals, net result, win rate update instantly
- **Persistent Storage** — SQLite database (auto-created)
- **Responsive Design** — Works on mobile, tablet & desktop
- **Premium UI** — Dark modern SaaS-style design

## Tech Stack

| Layer    | Technology                        |
|----------|-----------------------------------|
| Backend  | Python 3 + Flask + SQLite         |
| Frontend | Vanilla HTML / CSS / JS + Chart.js |
| Auth     | SHA-256 hashed admin code + session tokens |

## Quick Start

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/team-profit-dashboard.git
cd team-profit-dashboard
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
# or
pip3 install --user -r requirements.txt
```

### 3. Run the server

```bash
cd backend
python3 app.py
```

Open **http://localhost:5000** in your browser.

### Admin Access

1. Click the **Admin** button (top right)
2. Enter the code: `dmts9695`
3. Add / edit / delete entries from the Admin Panel

> The admin code is stored only as a SHA-256 hash on the backend. It is never exposed in the frontend source code.

## Project Structure

```
team-profit-dashboard/
├── backend/
│   └── app.py              # Flask API + DB + Auth
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── requirements.txt
├── .gitignore
└── README.md
```

## API Endpoints

| Method | Path                     | Auth | Description             |
|--------|--------------------------|------|-------------------------|
| GET    | `/api/stats?period=all`  | No   | Dashboard stats + chart |
| GET    | `/api/entries`           | No   | List all entries        |
| POST   | `/api/admin/login`       | No   | Login with admin code   |
| POST   | `/api/admin/logout`      | Yes  | Logout                  |
| POST   | `/api/admin/entries`     | Yes  | Add entry               |
| PUT    | `/api/admin/entries/:id` | Yes  | Update entry            |
| DELETE | `/api/admin/entries/:id` | Yes  | Delete entry            |

## Color Logic

- 🟢 **Green** → Profit / Win
- 🔴 **Red** → Loss
- 🔵 **Blue / Neutral** → General stats

## License

MIT
