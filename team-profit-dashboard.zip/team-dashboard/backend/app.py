#!/usr/bin/env python3
"""
Team Profit & Performance Dashboard - Backend
Professional Flask API with SQLite persistence and secure admin auth.
"""

import os
import sqlite3
import hashlib
import secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data.db")
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")

# Admin code hashed (SHA-256 of "dmts9695") - never store plain text
ADMIN_CODE_HASH = hashlib.sha256(b"dmts9695").hexdigest()

# Session tokens (in-memory for simplicity; use Redis in production)
active_sessions = {}

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app, supports_credentials=True)

# ──────────────────────────────────────────────
# Database helpers
# ──────────────────────────────────────────────

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("""
        CREATE TABLE IF NOT EXISTS entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('profit', 'loss')),
            amount REAL NOT NULL CHECK(amount >= 0),
            result TEXT NOT NULL CHECK(result IN ('win', 'loss')),
            note TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    db.commit()
    db.close()

# ──────────────────────────────────────────────
# Auth helpers
# ──────────────────────────────────────────────

def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        if not token or token not in active_sessions:
            return jsonify({"error": "Unauthorized", "message": "Admin access required"}), 401
        # Optional: expire sessions after 8 hours
        session = active_sessions[token]
        if datetime.utcnow() - session["created"] > timedelta(hours=8):
            del active_sessions[token]
            return jsonify({"error": "Session expired", "message": "Please login again"}), 401
        return f(*args, **kwargs)
    return decorated

# ──────────────────────────────────────────────
# Calculation helpers
# ──────────────────────────────────────────────

def compute_stats(db, period=None):
    """Compute all dashboard stats. period: daily|weekly|monthly|all"""
    query = "SELECT * FROM entries"
    params = []
    if period and period != "all":
        today = datetime.utcnow().date()
        if period == "daily":
            start = today.isoformat()
            query += " WHERE date = ?"
            params = [start]
        elif period == "weekly":
            start = (today - timedelta(days=today.weekday())).isoformat()
            query += " WHERE date >= ?"
            params = [start]
        elif period == "monthly":
            start = today.replace(day=1).isoformat()
            query += " WHERE date >= ?"
            params = [start]

    rows = db.execute(query, params).fetchall()

    total_profit = 0.0
    total_loss = 0.0
    total_wins = 0
    total_losses = 0

    for row in rows:
        amount = float(row["amount"])
        if row["type"] == "profit":
            total_profit += amount
        else:
            total_loss += amount
        if row["result"] == "win":
            total_wins += 1
        else:
            total_losses += 1

    net = total_profit - total_loss
    total_trades = total_wins + total_losses
    win_rate = (total_wins / total_trades * 100) if total_trades > 0 else 0.0

    return {
        "total_profit": round(total_profit, 2),
        "total_loss": round(total_loss, 2),
        "net_result": round(net, 2),
        "is_profit": net >= 0,
        "total_wins": total_wins,
        "total_losses": total_losses,
        "win_rate": round(win_rate, 1),
        "total_entries": len(rows)
    }

def get_chart_data(db, period="monthly"):
    """Return time-series data for charts."""
    query = "SELECT date, type, amount, result FROM entries ORDER BY date ASC"
    rows = db.execute(query).fetchall()

    # Group by date
    daily = {}
    for row in rows:
        d = row["date"]
        if d not in daily:
            daily[d] = {"profit": 0.0, "loss": 0.0, "wins": 0, "losses": 0}
        if row["type"] == "profit":
            daily[d]["profit"] += float(row["amount"])
        else:
            daily[d]["loss"] += float(row["amount"])
        if row["result"] == "win":
            daily[d]["wins"] += 1
        else:
            daily[d]["losses"] += 1

    labels = sorted(daily.keys())
    profit_data = [daily[d]["profit"] for d in labels]
    loss_data = [daily[d]["loss"] for d in labels]
    net_data = [daily[d]["profit"] - daily[d]["loss"] for d in labels]

    return {
        "labels": labels,
        "profit": profit_data,
        "loss": loss_data,
        "net": net_data
    }

# ──────────────────────────────────────────────
# API Routes
# ──────────────────────────────────────────────

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})

@app.route("/api/stats")
def get_stats():
    period = request.args.get("period", "all")
    db = get_db()
    stats = compute_stats(db, period)
    chart = get_chart_data(db, period)
    return jsonify({"stats": stats, "chart": chart})

@app.route("/api/entries")
def list_entries():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM entries ORDER BY date DESC, id DESC"
    ).fetchall()
    entries = [dict(row) for row in rows]
    return jsonify({"entries": entries})

@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    data = request.get_json() or {}
    code = data.get("code", "").strip()
    if not code:
        return jsonify({"error": "Access Denied", "message": "Admin code required"}), 401

    code_hash = hashlib.sha256(code.encode()).hexdigest()
    if code_hash != ADMIN_CODE_HASH:
        return jsonify({"error": "Access Denied", "message": "Invalid admin code"}), 401

    token = secrets.token_urlsafe(32)
    active_sessions[token] = {"created": datetime.utcnow()}
    return jsonify({
        "success": True,
        "token": token,
        "message": "Admin access granted"
    })

@app.route("/api/admin/logout", methods=["POST"])
@require_admin
def admin_logout():
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if token in active_sessions:
        del active_sessions[token]
    return jsonify({"success": True, "message": "Logged out"})

@app.route("/api/admin/entries", methods=["POST"])
@require_admin
def add_entry():
    data = request.get_json() or {}
    required = ["date", "type", "amount", "result"]
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing field: {field}"}), 400

    entry_type = data["type"].lower()
    result = data["result"].lower()
    if entry_type not in ("profit", "loss"):
        return jsonify({"error": "type must be profit or loss"}), 400
    if result not in ("win", "loss"):
        return jsonify({"error": "result must be win or loss"}), 400

    try:
        amount = float(data["amount"])
        if amount < 0:
            raise ValueError()
    except (ValueError, TypeError):
        return jsonify({"error": "amount must be a non-negative number"}), 400

    note = data.get("note", "")[:500]
    date = data["date"]  # expect YYYY-MM-DD
    created_at = datetime.utcnow().isoformat()

    db = get_db()
    cur = db.execute(
        """INSERT INTO entries (date, type, amount, result, note, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (date, entry_type, amount, result, note, created_at)
    )
    db.commit()
    entry_id = cur.lastrowid

    stats = compute_stats(db)
    return jsonify({
        "success": True,
        "message": "Entry added successfully",
        "id": entry_id,
        "stats": stats
    }), 201

@app.route("/api/admin/entries/<int:entry_id>", methods=["PUT"])
@require_admin
def update_entry(entry_id):
    data = request.get_json() or {}
    db = get_db()
    existing = db.execute("SELECT * FROM entries WHERE id = ?", (entry_id,)).fetchone()
    if not existing:
        return jsonify({"error": "Entry not found"}), 404

    entry_type = data.get("type", existing["type"]).lower()
    result = data.get("result", existing["result"]).lower()
    amount = data.get("amount", existing["amount"])
    date = data.get("date", existing["date"])
    note = data.get("note", existing["note"])

    if entry_type not in ("profit", "loss"):
        return jsonify({"error": "type must be profit or loss"}), 400
    if result not in ("win", "loss"):
        return jsonify({"error": "result must be win or loss"}), 400
    try:
        amount = float(amount)
        if amount < 0:
            raise ValueError()
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400

    db.execute(
        """UPDATE entries SET date=?, type=?, amount=?, result=?, note=?
           WHERE id=?""",
        (date, entry_type, amount, result, note[:500], entry_id)
    )
    db.commit()

    stats = compute_stats(db)
    return jsonify({
        "success": True,
        "message": "Changes saved successfully.",
        "stats": stats
    })

@app.route("/api/admin/entries/<int:entry_id>", methods=["DELETE"])
@require_admin
def delete_entry(entry_id):
    db = get_db()
    existing = db.execute("SELECT id FROM entries WHERE id = ?", (entry_id,)).fetchone()
    if not existing:
        return jsonify({"error": "Entry not found"}), 404

    db.execute("DELETE FROM entries WHERE id = ?", (entry_id,))
    db.commit()

    stats = compute_stats(db)
    return jsonify({
        "success": True,
        "message": "Entry deleted successfully",
        "stats": stats
    })

# ──────────────────────────────────────────────
# Serve Frontend
# ──────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(FRONTEND_DIR, path)

# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print("🚀 Team Profit & Performance Dashboard")
    print("   Backend running on http://0.0.0.0:5000")
    print("   Admin code is secured (hashed) — never exposed to frontend.")
    app.run(host="0.0.0.0", port=5000, debug=True)
